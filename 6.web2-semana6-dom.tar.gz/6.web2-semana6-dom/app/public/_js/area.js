function calcularArea() {
    let inputNome = document.querySelector('[name=nome]');
    let nome = inputNome.value;
    let inputMedida = document.querySelector('[name=medida]');
    let medida = parseFloat(inputMedida.value);

    let area = parseFloat((4 * (medida ** 2) * (1 / Math.tan(Math.PI / 16))).toFixed(2));
    let grande = area > 400;

    let divResposta = document.querySelector('#resposta');
    let div = document.createElement('div');
    div.textContent = 'Olá, ' + nome + '! a medida do lado é ' + medida + '. Então a área é ' + area;
    if (grande) {
        div.classList.add('grande');
        div.classList.remove('pequena');
    }
    else {
        div.classList.remove('grande');
        div.classList.add('pequena');
    }

    divResposta.append(div);
}